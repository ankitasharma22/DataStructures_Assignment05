﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment04
{
    interface IBasicFunctionality
    {
        void Push(int input);
        void Pop();
        void Display();
        void Sort();
    }
}
